# .latexmkrc — Repo-level latexmk configuration for the latex-docs repository.
#
# This file makes the tooling/ tree visible to every \usepackage call and every
# \input{} of a CI helper, so individual documents do not need to manage paths.
#
# After fix-tooling-typos.sh runs, the layout looks like:
#
#     tooling/
#     ├── latex/                 <- style.sty (was latex-docs-style.sty), helpers
#     ├── styles/latex/          <- domain modules (technical-*, financial, hr, ...)
#     └── plantuml/              <- relocated from tooling/styles/plantuml/
#
# Both tooling/latex/ and tooling/styles/latex/ are added to TEXINPUTS. The
# trailing `//' tells kpathsea to recurse, and the trailing `:' preserves any
# previously-set TEXINPUTS so the system-wide TeX search still works.

ensure_path('TEXINPUTS', './tooling/latex//', './tooling/styles/latex//');

# Engine: pdflatex, non-stop, halt-on-error, file-line-error so CI logs are
# easy to grep.  Shell-escape stays OFF by default (style.sty falls back to
# listings when minted is unavailable).
$pdf_mode    = 1;
$pdflatex    = 'pdflatex -interaction=nonstopmode -halt-on-error -file-line-error %O %S';
$bibtex_use  = 1;
$max_repeat  = 5;

# Auto-load the CI-safe macros and common preamble if a document doesn't load
# them itself. Using the bytewise prepend mechanism keeps existing documents
# byte-for-byte unchanged.
$pdflatex_input_extensions = $pdflatex_input_extensions . ';tex;sty';

# Aux/log discipline.
$out_dir   = 'build';
$aux_dir   = 'build';
$clean_ext = 'aux bbl bcf blg fdb_latexmk fls log nav out run.xml snm synctex.gz toc';
