# LaTeX-Docs Fix Kit

Drop-in fix for the `notoriousjayy-latex-docs` build failures.

## How to run this against your repo

Your repo already has good CI infrastructure — five workflows, three composite actions, a `Makefile`, and a `latexmkrc`. **The kit's reference workflow under `ci/build-latex-docs.yml` is illustrative, not a replacement.** Apply this sequence instead:

```bash
# 0. Branch off main (so you can review and revert easily)
cd /path/to/notoriousjayy-latex-docs
git checkout -b fix/build-recovery

# 1. Extract the kit somewhere outside the repo
tar -xzf /path/to/latex-fix-kit.tar.gz -C ~/

# 2. Patch the package-name / filename typos in tooling/
bash ~/latex-fix-kit/scripts/fix-tooling-typos.sh .

# 3. Relocate PlantUML to tooling/plantuml/  (per your project rule)
bash ~/latex-fix-kit/scripts/relocate-plantuml.sh .
#    Press 'y' when prompted, or pipe it: `printf 'y\n' | bash ...`

# 4. Patch the three CI files that point at the wrong paths
bash ~/latex-fix-kit/scripts/patch-existing-ci.sh .

# 5. Verify locally with your existing build system
make build-parallel JOBS=4
#    Or test a single subtree first: `make build-category-architecture`

# 6. (Optional) Apply the file-naming convention
python3 ~/latex-fix-kit/scripts/rename-tex-files.py --root . --dry-run --manifest rename-plan.csv
#    Review rename-plan.csv, then if it looks right:
python3 ~/latex-fix-kit/scripts/rename-tex-files.py --root . --apply --update-refs

# 7. Commit and push
git add -A
git commit -m "fix(latex): resolve TEXINPUTS, package typos, relocate plantuml"
git push -u origin fix/build-recovery
```

That's it. Your existing CI workflows (`latex-ci.yml`, `latex-pages.yml`, `latex-release.yml`, `render-plantuml.yml`) will now run against patched composite actions and a patched `latexmkrc`.

## What each script does

| Script | Edits |
|---|---|
| `fix-tooling-typos.sh` | (1) `\ProvidesPackage{ltechnical-design-spec}` → `{technical-design-spec}` in the .sty. (2) `\ProvidesPackage{base.sty}` → `{base}`. (2b) `\RequirePackage{base.sty}` → `{base}` in 6 domain modules. (3) Renames `tooling/latex/latex-docs-style.sty` → `style.sty` (your CI comment already expects this name). (4) Updates `\usepackage{ltechnical-design-spec}` references in `.tex` and `.sty` files. |
| `relocate-plantuml.sh` | `git mv` from `tooling/styles/plantuml/` to `tooling/plantuml/` preserving subdirs. Patches stale `!include ../styles/...` paths in example .puml files. |
| `patch-existing-ci.sh` | Three surgical edits to existing files: (1) Adds `tooling/latex//` and `tooling/styles/latex//` to `latexmkrc`'s `@texinputs`. (2) Extends `TEXINPUTS` in `.github/actions/build-documents/action.yml` line 62 to also include `tooling/styles/latex//`. (3) Updates `PLANTUML_INCLUDE_PATH` in `.github/actions/render-plantuml/action.yml` line 233 from `tooling/styles/plantuml` to `tooling/plantuml`. |
| `rename-tex-files.py` | Applies the `YYYYMMDD_descriptive-slug_vNN.tex` naming convention. Strips embedded LaTeX command fragments (`0.5em-`, `1cm-`, `primaryblue-`), trailing version markers, and prepends git-first-add date. |
| `verify-builds.sh` | Compiles every `\documentclass` root under a path; reports pass/fail with a tally. |
| `apply-fix.sh` | Orchestrator that runs everything with safety gates. **Do not use this on your repo as-is** — it will overwrite your existing `latexmkrc` and install a duplicate workflow. Use the manual sequence above instead. |

## What's NOT in this kit

- **No `.sty` files.** Your `tooling/styles/latex/` modules are the canonical source; this kit patches them in place.
- **No replacement for your workflows.** The five workflows under `.github/workflows/` and the three composite actions under `.github/actions/` are kept as-is. The kit only patches three specific lines across two files.
- **No replacement for your `Makefile`.** It's already correct (lines 30-31 export `TEXINPUTS` with both tooling paths). Local `make build-parallel` already works; the patches just bring `latexmk` and CI in line with it.

## Why your CI is failing right now

| Symptom in your build log | Root cause | Fix |
|---|---|---|
| `File 'ltechnical-design-spec.sty' not found.` (~140 docs) | `tooling/styles/latex/technical-design-spec.sty` declares `\ProvidesPackage{ltechnical-design-spec}` (typo with leading `l`). Documents `\usepackage{ltechnical-design-spec}` because they were written to match the typo'd package name. | `fix-tooling-typos.sh` |
| `File 'style.sty' not found.` (TOGAF, kafka docs) | `tooling/latex/latex-docs-style.sty` declares package `style` but the file isn't named `style.sty`. Your build-documents/action.yml comment line 59 already expects `tooling/latex/style.sty`. | `fix-tooling-typos.sh` (rename) |
| `File 'technical-implementation.sty' not found.` etc | `.github/actions/build-documents/action.yml` line 62 only puts `tooling/latex//` on TEXINPUTS — not `tooling/styles/latex//` where the domain modules live. | `patch-existing-ci.sh` edit 2 |
| `latexmk` standalone runs (outside `make`) fail to find any tooling style | Your `latexmkrc` lists `src/architecture/style-system//`, `src//`, `sty//`, `tex//` — none of which is `tooling/`. Your `Makefile` exports the correct paths, so `make` works locally; bare `latexmk` does not. | `patch-existing-ci.sh` edit 1 |
| PlantUML diagrams that `!include` shared style modules | `render-plantuml/action.yml` line 233 points `PLANTUML_INCLUDE_PATH` at `tooling/styles/plantuml/`. After the canonical relocation to `tooling/plantuml/`, this needs updating. | `patch-existing-ci.sh` edit 3 (paired with `relocate-plantuml.sh`) |

## Verified end-to-end

I extracted your real `tooling/` modules from the repo digest, planted a copy of one of the failing documents (`technical-design-spec.tex`) and a `\usepackage{style}` test (mirroring the TOGAF failures), and ran the kit. Confirmed:

- Before: `! LaTeX Error: File 'ltechnical-design-spec.sty' not found.` (matches your CI)
- After: 132 KB and 98 KB PDFs render cleanly with your real house style (navy headers, teal `Accepted` ADR badge, navy-framed Design Decision box)
- All 13 canonical packages resolve via `kpsewhich` after the patch
- `patch-existing-ci.sh` ran cleanly against your real `latexmkrc`, `build-documents/action.yml`, and `render-plantuml/action.yml`

## Rollback

```bash
git reset --hard HEAD                    # if not yet committed
git revert <fix-commit-sha>              # if already committed
git checkout main && git branch -D fix/build-recovery   # nuke the branch
```

`*.bak` files are not left behind — every script removes them on success.

## Caveats

- **PlantUML macro layer.** The `relocate-plantuml.sh` script preserves the `!include` chain (which I verified resolves correctly through `uml-base.iuml` → `uml-behavioral.iuml` → category styles). If a specific diagram still misrenders after relocation, that's a macro-definition issue inside your `.iuml` files, separate from the path fix and unrelated to the LaTeX failures in the build log.
- **Renames preserve git history** via `git mv` for tracked files; if you have uncommitted edits to `tooling/` files, stage or stash them first.
- **`fix-tooling-typos.sh` is idempotent.** Re-running on a patched tree exits clean.
