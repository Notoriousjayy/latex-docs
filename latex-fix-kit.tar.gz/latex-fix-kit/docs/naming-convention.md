# File-Naming Convention for `latex-docs`

## Format

```
YYYYMMDD_descriptive-slug.tex
YYYYMMDD_descriptive-slug_vNN.tex   (versioned variants)
```

| Position | Rule | Example |
|---|---|---|
| 1 | ISO date, no separators, 8 chars | `20260509` |
| 2 | Underscore separator | `_` |
| 3 | Lowercase hyphenated slug, ≤ 50 chars | `ghas-bulk-dismissal-runbook` |
| 4 *(optional)* | Underscore + `v` + 2-digit version | `_v02` |
| 5 | Extension | `.tex` |

**Total filename length target: under 70 characters.** The slug describes the document, not its formatting.

## Why this format

- **Date prefix sorts chronologically** — matches how the repo is most often browsed.
- **Underscore between date and slug, hyphens within the slug** — the underscore makes the date a visually distinct token.
- **Lowercase only** — case sensitivity bites on Linux CI but not on macOS local; that mismatch silently breaks `\input{}`.
- **No `final`, `final2`, `FINAL_v2`** — use `_v02`, `_v03`. They sort, they're unambiguous, they survive merges.
- **50-char slug ceiling** — the previous repo had filenames up to 130 characters, many containing raw LaTeX command fragments (`0.5em-`, `1cm-`, `primaryblue-`).

## What `rename-tex-files.py` strips automatically

- LaTeX measurements: `0.5em`, `1cm`, `12pt`, `1.5em`, `0.35em`, `2pt`, `4pt` (any digit + `em|pt|cm|mm|in|ex|bp|pc`)
- Color tokens (legacy + canonical palette): `primaryblue`, `secondaryblue`, `Navy`, `Steel`, `Teal`, `Brick`, `Ink`, `Soft`, `Meta`, `Accent`, `CardBack`, `CardFrame`
- Trailing `-N` version markers (`N` = 1–99) → `_vNN`

## Examples

| Before | After |
|---|---|
| `1cm-primaryblue-ai-driven-3d-model-generation-for-technical-games-0.3cm-tool-comparison-pipeline-design-and-implementati.tex` | `20260509_ai-driven-3d-model-generation-for-technical-games.tex` |
| `the-deployment-architectural-style-0.5em-a-comprehensive-reference-for-mapping-software-to-hardware.tex` | `20260509_the-deployment-architectural-style-a-comprehensive.tex` |
| `1.5emcodeql-capabilities-exam-ready-cheat-sheet-0.5em.tex` | `20260509_codeql-capabilities-exam-ready-cheat-sheet.tex` |
| `study-plan-the-design-of-sites-2nd-ed.-0.25em-full-user-story-set-by-chapter-pattern-group-2.tex` | `20260509_study-plan-the-design-of-sites-2nd-ed-full-user_v02.tex` |
| `executive-summary.tex` (already clean) | `20260509_executive-summary.tex` |
| `user-stories-2.tex` | `20260509_user-stories_v02.tex` |

## When to bump the version

| Change | Action |
|---|---|
| Typo / formatting fix | Edit in place, no rename |
| New section, expanded scope, restructured TOC | Bump `_v02` → `_v03` |
| Forking a doc into a new audience variant | New filename with a distinct slug suffix (e.g. `_executive`, `_engineering`) |
| Refreshing a periodic deliverable | New date prefix, slug stays the same; the two coexist |

## Path conventions

- Subject-area directories under `src/` are unchanged: `src/architecture/views-and-beyond/style-catalogs/...`
- File renames preserve their parent directory; `rename-tex-files.py` never moves files between directories
- Cross-references (`\input{}`, `\include{}`, `\subfile{}`, `\InputIfFileExists{}`, `\includeonly{}`) are rewritten automatically when the script runs with `--update-refs`

## Hard rules

1. **No spaces.** Ever.
2. **No special characters** beyond `[a-z0-9_-]` and the single dot before the extension.
3. **No uppercase.**
4. **No `final`, `latest`, `current`, `draft`** in the name. Use the version suffix.
5. **No date in slugs** beyond the YYYYMMDD prefix (a slug with `2024` for *content reasons* — `owasp-top-10-2024` — is fine).
