#!/usr/bin/env python3
"""rename-tex-files.py — Apply the latex-docs file-naming convention.

Convention (per docs/naming-convention.md):
  YYYYMMDD_descriptive-slug.tex                 # standard
  YYYYMMDD_descriptive-slug_v02.tex              # versioned variants

Walks src/ only — never touches files under tooling/.

Rules applied (in order):
  1. Strip .tex extension for processing.
  2. Remove embedded LaTeX measurement fragments (0.5em, 1cm, 12pt, 1.5em, ...).
  3. Remove embedded color tokens (primaryblue, Navy, Steel, Teal, ...).
  4. Convert trailing -N (1..99) to _vNN.
  5. Collapse runs of hyphens; strip leading/trailing punctuation.
  6. Lowercase.
  7. Truncate slug to MAX_SLUG_CHARS (default 50).
  8. Prepend YYYYMMDD_ from git first-add date, else mtime, else today.

  Default mode: dry-run. Pass --apply to commit.
"""
from __future__ import annotations

import argparse
import csv
import os
import re
import shutil
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

MAX_SLUG_CHARS = 50

MEASUREMENT_RE = re.compile(
    r"\d+(?:[.,]\d+)?(?:em|pt|cm|mm|in|ex|bp|pc)",
    re.IGNORECASE,
)

# Includes both legacy aliases and the canonical Navy/Steel/Teal/Brick palette.
COLOR_RE = re.compile(
    r"(?:primaryblue|secondaryblue|accentteal|warnred|paperbg|"
    r"navy|steel|teal|brick|ink|soft|meta|accent|cardback|cardframe)-?",
    re.IGNORECASE,
)

TRAILING_VERSION_RE = re.compile(r"-(\d{1,2})$")

REF_PATTERNS = [
    re.compile(r"(\\input\s*\{)([^}]+)(\})"),
    re.compile(r"(\\include\s*\{)([^}]+)(\})"),
    re.compile(r"(\\subfile\s*\{)([^}]+)(\})"),
    re.compile(r"(\\InputIfFileExists\s*\{)([^}]+)(\})"),
    re.compile(r"(\\includeonly\s*\{)([^}]+)(\})"),
]


def normalize_slug(stem: str) -> tuple[str, str | None]:
    slug = stem.lower()
    prev = None
    while prev != slug:
        prev = slug
        slug = MEASUREMENT_RE.sub("-", slug)
        slug = COLOR_RE.sub("-", slug)
    version = None
    m = TRAILING_VERSION_RE.search(slug)
    if m:
        n = int(m.group(1))
        version = f"_v{n:02d}"
        slug = slug[: m.start()]
    slug = re.sub(r"[^a-z0-9_-]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    slug = re.sub(r"_+", "_", slug)
    slug = slug.strip("-_.")
    if len(slug) > MAX_SLUG_CHARS:
        cut = slug[:MAX_SLUG_CHARS]
        last_hyphen = cut.rfind("-")
        if last_hyphen >= MAX_SLUG_CHARS - 12:
            cut = cut[:last_hyphen]
        slug = cut.rstrip("-_.")
    return slug, version


def git_first_added(path: Path) -> date | None:
    try:
        out = subprocess.run(
            ["git", "log", "--diff-filter=A", "--follow", "--format=%aI", "--", str(path)],
            check=True, capture_output=True, text=True,
        ).stdout.strip().splitlines()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None
    if not out:
        return None
    earliest = out[-1].strip()
    try:
        return datetime.fromisoformat(earliest).date()
    except ValueError:
        return None


def file_date(path: Path, fallback: date) -> date:
    d = git_first_added(path)
    if d is not None:
        return d
    try:
        return date.fromtimestamp(path.stat().st_mtime)
    except OSError:
        return fallback


def plan_renames(repo_root: Path, today: date) -> list[tuple[Path, Path]]:
    src = repo_root / "src"
    if not src.is_dir():
        sys.exit(f"error: {src} not found — run from repo root or pass --root")
    plan: list[tuple[Path, Path]] = []
    seen_targets: set[Path] = set()
    for tex in sorted(src.rglob("*.tex")):
        stem = tex.stem
        slug, version = normalize_slug(stem)
        if not slug:
            continue
        d = file_date(tex, today)
        date_prefix = d.strftime("%Y%m%d")
        new_stem = f"{date_prefix}_{slug}{version or ''}"
        new_name = f"{new_stem}.tex"
        new_path = tex.with_name(new_name)
        base = new_path
        n = 2
        while new_path != tex and new_path in seen_targets:
            new_path = base.with_name(f"{base.stem}_v{n:02d}{base.suffix}")
            n += 1
        seen_targets.add(new_path)
        if new_path != tex:
            plan.append((tex, new_path))
    return plan


def build_ref_map(plan: list[tuple[Path, Path]], repo_root: Path) -> dict[str, str]:
    rmap: dict[str, str] = {}
    src = repo_root / "src"
    for old, new in plan:
        old_rel = old.relative_to(src).with_suffix("")
        new_rel = new.relative_to(src).with_suffix("")
        rmap[str(old_rel).replace(os.sep, "/")] = str(new_rel).replace(os.sep, "/")
        rmap[old.stem] = new.stem
    return rmap


def update_references(repo_root: Path, rmap: dict[str, str], apply: bool) -> int:
    changed = 0
    for tex in sorted((repo_root / "src").rglob("*.tex")):
        text = tex.read_text(encoding="utf-8")
        new_text = text
        for pat in REF_PATTERNS:
            def _sub(m: re.Match) -> str:
                target = m.group(2).strip()
                naked = target[:-4] if target.endswith(".tex") else target
                replacement = rmap.get(naked) or rmap.get(naked.split("/")[-1])
                if replacement is None:
                    return m.group(0)
                return f"{m.group(1)}{replacement}{m.group(3)}"
            new_text = pat.sub(_sub, new_text)
        if new_text != text:
            changed += 1
            if apply:
                tex.write_text(new_text, encoding="utf-8")
    return changed


def is_git_tracked(path: Path) -> bool:
    try:
        subprocess.run(
            ["git", "ls-files", "--error-unmatch", str(path)],
            check=True, capture_output=True,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def apply_renames(plan: list[tuple[Path, Path]]) -> None:
    for old, new in plan:
        new.parent.mkdir(parents=True, exist_ok=True)
        if is_git_tracked(old):
            subprocess.run(["git", "mv", str(old), str(new)], check=True)
        else:
            shutil.move(str(old), str(new))


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--apply", action="store_true", help="Actually rename (default: dry-run)")
    parser.add_argument("--dry-run", action="store_true", help="Explicit dry-run (default behavior)")
    parser.add_argument("--update-refs", action="store_true",
                        help="Patch \\input{}/\\include{} cross-references")
    parser.add_argument("--commit", action="store_true",
                        help="git commit after applying")
    parser.add_argument("--manifest", type=Path,
                        help="Write manifest CSV to this path (default: stdout)")
    args = parser.parse_args()

    if args.dry_run:
        args.apply = False

    today = date.today()
    plan = plan_renames(args.root, today)

    out = open(args.manifest, "w", newline="") if args.manifest else sys.stdout
    writer = csv.writer(out)
    writer.writerow(["old_path", "new_path"])
    for old, new in plan:
        writer.writerow([str(old.relative_to(args.root)), str(new.relative_to(args.root))])
    if args.manifest:
        out.close()

    print(f"==> Planned {len(plan)} renames.", file=sys.stderr)

    if not args.apply:
        print("==> Dry-run only. Re-run with --apply to execute.", file=sys.stderr)
        return 0

    rmap = build_ref_map(plan, args.root)
    apply_renames(plan)
    print(f"==> Renamed {len(plan)} files.", file=sys.stderr)

    if args.update_refs:
        changed = update_references(args.root, rmap, apply=True)
        print(f"==> Updated cross-references in {changed} file(s).", file=sys.stderr)

    if args.commit:
        subprocess.run(["git", "add", "."], check=True, cwd=args.root)
        subprocess.run(
            ["git", "commit", "-m",
             "chore(naming): apply YYYYMMDD_slug naming convention"],
            check=True, cwd=args.root,
        )
        print("==> Committed.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
