#!/usr/bin/env bash
# patch-existing-ci.sh — Patch the three TEXINPUTS / include-path bugs in
# your repo's existing CI infrastructure. Use this INSTEAD OF dropping the
# kit's reference latexmkrc and workflow into place; your real infrastructure
# is more sophisticated and just needs surgical edits.
#
# Edits applied:
#
#   1. latexmkrc (repo root)
#      Add tooling/latex//  AND  tooling/styles/latex//  to @texinputs.
#      Without this, latexmk invocations (outside of `make`) don't see the
#      style modules.
#
#   2. .github/actions/build-documents/action.yml
#      Extend the TEXINPUTS export to include tooling/styles/latex//.
#      Currently only tooling/latex// is on the path, so domain modules like
#      technical-design-spec, business-admin, financial, etc. are not found.
#
#   3. .github/actions/render-plantuml/action.yml
#      Update PLANTUML_INCLUDE_PATH to point at tooling/plantuml (the
#      relocated canonical location), instead of tooling/styles/plantuml.
#
# Idempotent: re-running on a patched tree is a no-op.
#
# Usage: ./scripts/patch-existing-ci.sh [REPO_ROOT]

set -euo pipefail
REPO="${1:-$(pwd)}"
cd "$REPO"

if [[ ! -f latexmkrc && ! -f .latexmkrc ]]; then
    echo "error: neither latexmkrc nor .latexmkrc found in $REPO" >&2
    exit 2
fi

# -----------------------------------------------------------------------------
# Edit 1: latexmkrc
# -----------------------------------------------------------------------------
echo "==> Edit 1/3: latexmkrc — add tooling/ paths to @texinputs"
LMKRC="latexmkrc"
[[ -f "$LMKRC" ]] || LMKRC=".latexmkrc"

if grep -q '"\$root/tooling/latex//"' "$LMKRC"; then
    echo "    already patched: $LMKRC"
else
    # Insert two lines at the top of the @texinputs array.
    python3 - <<PYEOF
import re, pathlib
p = pathlib.Path("$LMKRC")
text = p.read_text()
new = re.sub(
    r'(my @texinputs = \(\n)',
    r'\1    "\$root/tooling/latex//",         # canonical house style (style.sty + helpers)\n'
    r'    "\$root/tooling/styles/latex//",  # domain modules (technical-*, financial, hr, ...)\n',
    text, count=1,
)
if new == text:
    raise SystemExit("    !! could not locate '@texinputs = (' in $LMKRC")
p.write_text(new)
print("    patched: $LMKRC")
PYEOF
fi

# -----------------------------------------------------------------------------
# Edit 2: .github/actions/build-documents/action.yml
# -----------------------------------------------------------------------------
echo
echo "==> Edit 2/3: .github/actions/build-documents/action.yml — TEXINPUTS"
BD=".github/actions/build-documents/action.yml"
if [[ ! -f "$BD" ]]; then
    echo "    skipped (file not found): $BD"
elif grep -q 'tooling/styles/latex//' "$BD"; then
    echo "    already patched: $BD"
else
    sed -i.bak \
        -e 's|export TEXINPUTS="\${GITHUB_WORKSPACE}/tooling/latex//:\${TEXINPUTS:-}"|export TEXINPUTS="${GITHUB_WORKSPACE}/tooling/latex//:${GITHUB_WORKSPACE}/tooling/styles/latex//:${TEXINPUTS:-}"|' \
        "$BD"
    rm -f "${BD}.bak"
    if grep -q 'tooling/styles/latex//' "$BD"; then
        echo "    patched: $BD"
    else
        echo "    !! sed match failed; check $BD line 62 by hand."
        exit 1
    fi
fi

# -----------------------------------------------------------------------------
# Edit 3: .github/actions/render-plantuml/action.yml
# -----------------------------------------------------------------------------
echo
echo "==> Edit 3/3: .github/actions/render-plantuml/action.yml — PLANTUML_INCLUDE_PATH"
RP=".github/actions/render-plantuml/action.yml"
if [[ ! -f "$RP" ]]; then
    echo "    skipped (file not found): $RP"
elif grep -q 'PLANTUML_INCLUDE_PATH="\${GITHUB_WORKSPACE}/tooling/plantuml"' "$RP"; then
    echo "    already patched: $RP"
else
    sed -i.bak \
        -e 's|PLANTUML_INCLUDE_PATH="\${GITHUB_WORKSPACE}/tooling/styles/plantuml"|PLANTUML_INCLUDE_PATH="${GITHUB_WORKSPACE}/tooling/plantuml"|' \
        "$RP"
    rm -f "${RP}.bak"
    if grep -q 'PLANTUML_INCLUDE_PATH="\${GITHUB_WORKSPACE}/tooling/plantuml"' "$RP"; then
        echo "    patched: $RP"
    else
        echo "    !! sed match failed; check $RP line 233 by hand."
        exit 1
    fi
fi

echo
echo "==> All three edits applied."
echo
echo "Next steps:"
echo "  1. git diff       (review the changes)"
echo "  2. make build-parallel JOBS=4   (verify locally)"
echo "  3. git add -A && git commit -m 'fix(ci): add tooling/styles/latex to TEXINPUTS, relocate plantuml'"
