#!/usr/bin/env bash
# relocate-plantuml.sh — Move PlantUML assets from tooling/styles/plantuml/ to
# tooling/plantuml/, per the canonical location stated in the project rules:
#
#     "PlantUML must use /tooling/plantuml directory."
#
# This script:
#   * Moves every file from tooling/styles/plantuml/ (recursively) to
#     tooling/plantuml/, preserving the subdirectory structure
#     (behavioral/, interaction/, structural/).
#   * Uses `git mv' on tracked files so history follows.
#   * Removes the now-empty tooling/styles/plantuml/ directory.
#   * If tooling/styles/ is empty afterwards, removes that too.
#   * Does NOT rewrite .puml `!include' lines or PlantUML config references —
#     those use relative paths (`!include ../uml-base.iuml') that still resolve
#     correctly when the whole tree moves together.
#
# Usage: ./scripts/relocate-plantuml.sh [REPO_ROOT]

set -euo pipefail

REPO_ROOT="${1:-$(pwd)}"
cd "$REPO_ROOT"

SRC_DIR="tooling/styles/plantuml"
DST_DIR="tooling/plantuml"

if [[ ! -d "$SRC_DIR" ]]; then
    if [[ -d "$DST_DIR" ]]; then
        echo "==> PlantUML already at $DST_DIR. Nothing to do."
        exit 0
    fi
    echo "error: neither $SRC_DIR nor $DST_DIR exists" >&2
    exit 2
fi

if [[ -d "$DST_DIR" ]]; then
    echo "warning: $DST_DIR already exists." >&2
    echo "         Will merge $SRC_DIR into it. Files in $DST_DIR will not be overwritten." >&2
    read -r -p "Proceed? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || exit 1
fi

mkdir -p "$DST_DIR"

GIT_OK=0
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    GIT_OK=1
fi

echo "==> Moving PlantUML assets: $SRC_DIR  ->  $DST_DIR"
MOVED=0
SKIPPED=0
while IFS= read -r -d '' src_file; do
    rel="${src_file#${SRC_DIR}/}"
    dst_file="${DST_DIR}/${rel}"
    if [[ -e "$dst_file" ]]; then
        echo "    skipped (target exists): $rel"
        SKIPPED=$((SKIPPED + 1))
        continue
    fi
    mkdir -p "$(dirname "$dst_file")"
    if (( GIT_OK )) && git ls-files --error-unmatch "$src_file" >/dev/null 2>&1; then
        git mv "$src_file" "$dst_file"
    else
        mv "$src_file" "$dst_file"
    fi
    MOVED=$((MOVED + 1))
done < <(find "$SRC_DIR" -type f -print0)

echo "    moved $MOVED file(s); skipped $SKIPPED."

# -------------------------------------------------------------------------
# Post-relocation: patch stale `!include ../styles/...` references in the
# example .puml files. These were authored when the directory layout was
# different and never resolved cleanly even before relocation. After the
# move, the canonical sibling paths are simply (no prefix):
#     !include behavioral/<name>.iuml
#     !include interaction/<name>.iuml
#     !include structural/<name>.iuml
# -------------------------------------------------------------------------
echo
echo "==> Patching stale '!include ../styles/...' references in examples"
PATCHED_INC=0
mapfile -t PUML_FILES < <(find "$DST_DIR" \( -name '*.puml' -o -name '*.iuml' \) -type f)
for f in "${PUML_FILES[@]}"; do
    if grep -q '!include[[:space:]]*\.\./styles/' "$f"; then
        # Use '#' as the sed delimiter so '|' inside the alternation doesn't clash.
        sed -i.bak -E 's#!include[[:space:]]+\.\./styles/(behavioral|interaction|structural)/#!include \1/#g' "$f"
        rm -f "${f}.bak"
        PATCHED_INC=$((PATCHED_INC + 1))
        echo "    patched: $f"
    fi
done
echo "    cleaned $PATCHED_INC file(s)."

# Clean up empty source directories.
echo
echo "==> Cleaning up empty source dirs"
find "$SRC_DIR" -type d -empty -delete 2>/dev/null || true
[[ -d "$SRC_DIR" ]] || echo "    removed: $SRC_DIR"

if [[ -d "tooling/styles" ]] && [[ -z "$(find tooling/styles -mindepth 1 -type f 2>/dev/null)" ]]; then
    echo "    tooling/styles/ has no files left; review whether to remove or keep for tooling/styles/latex/"
fi

echo
echo "==> Done. Update CI/build to use -Dplantuml.include.path=$DST_DIR for PlantUML."
