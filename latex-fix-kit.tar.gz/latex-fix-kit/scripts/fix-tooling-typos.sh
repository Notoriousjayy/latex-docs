#!/usr/bin/env bash
# fix-tooling-typos.sh — Patch the package-name / filename mismatches in tooling/.
#
# Three fixes, in this order:
#   (1) tooling/styles/latex/technical-design-spec.sty
#       \ProvidesPackage{ltechnical-design-spec}  ->  \ProvidesPackage{technical-design-spec}
#       Reason: the filename is technical-design-spec.sty, so the package name
#       must match. This is the single typo behind ~140 of the build failures.
#
#   (2) tooling/styles/latex/base.sty
#       \ProvidesPackage{base.sty}  ->  \ProvidesPackage{base}
#       Reason: \ProvidesPackage takes a package name without the .sty suffix.
#       Cosmetic, but eliminates the LaTeX warning that fires on every build.
#
#   (3) tooling/latex/latex-docs-style.sty  ->  tooling/latex/style.sty
#       Reason: documents \usepackage{style}, which makes LaTeX look for style.sty.
#       The file declares \ProvidesPackage{style} so the rename matches its
#       intended package name.
#
#   (4) Patch any remaining \usepackage{ltechnical-design-spec} references
#       across all .tex files to use the corrected package name.
#
# Usage: ./scripts/fix-tooling-typos.sh [REPO_ROOT]
#        REPO_ROOT defaults to the current directory.
#
# Idempotent: re-running on a clean tree is a no-op.

set -euo pipefail

REPO_ROOT="${1:-$(pwd)}"
cd "$REPO_ROOT"

if [[ ! -d "tooling" ]]; then
    echo "error: $REPO_ROOT/tooling not found — run from repo root or pass it in" >&2
    exit 2
fi

echo "==> Fix 1/4: \\ProvidesPackage typo in technical-design-spec.sty"
TDS="tooling/styles/latex/technical-design-spec.sty"
if [[ -f "$TDS" ]]; then
    if grep -q '\\ProvidesPackage{ltechnical-design-spec}' "$TDS"; then
        sed -i.bak 's/\\ProvidesPackage{ltechnical-design-spec}/\\ProvidesPackage{technical-design-spec}/g' "$TDS"
        rm -f "${TDS}.bak"
        echo "    patched: $TDS"
    else
        echo "    already clean: $TDS"
    fi
else
    echo "    skipped (file not found): $TDS"
fi

echo
echo "==> Fix 2/4: \\ProvidesPackage{base.sty} stylistic warning"
BASE="tooling/styles/latex/base.sty"
if [[ -f "$BASE" ]]; then
    if grep -q '\\ProvidesPackage{base\.sty}' "$BASE"; then
        sed -i.bak 's/\\ProvidesPackage{base\.sty}/\\ProvidesPackage{base}/g' "$BASE"
        rm -f "${BASE}.bak"
        echo "    patched: $BASE"
    else
        echo "    already clean: $BASE"
    fi
else
    echo "    skipped (file not found): $BASE"
fi

# Companion fix: every domain module \RequirePackage{base.sty} (with the
# spurious .sty suffix). LaTeX appends another .sty, looks for base.sty.sty,
# and falls back. The original code worked by accident because both ends had
# the same typo. After Fix 2, the \RequirePackage end must also be cleaned.
echo
echo "==> Fix 2b: \\RequirePackage{X.sty} -> \\RequirePackage{X} in tooling/"
PATCHED_RP=0
mapfile -t STY_FILES < <(find tooling -name '*.sty' -type f 2>/dev/null)
for f in "${STY_FILES[@]}"; do
    # Match any  \RequirePackage{<name>.sty}  where <name> is a typical pkg name.
    # Only edit lines that are NOT inside a comment.
    if grep -qE '^[^%]*\\RequirePackage\{[a-zA-Z][a-zA-Z0-9-]*\.sty\}' "$f"; then
        sed -i.bak -E 's/(\\RequirePackage)\{([a-zA-Z][a-zA-Z0-9-]*)\.sty\}/\1{\2}/g' "$f"
        rm -f "${f}.bak"
        PATCHED_RP=$((PATCHED_RP + 1))
        echo "    patched: $f"
    fi
done
echo "    cleaned $PATCHED_RP file(s)."

echo
echo "==> Fix 3/4: rename latex-docs-style.sty -> style.sty"
SRC="tooling/latex/latex-docs-style.sty"
DST="tooling/latex/style.sty"
if [[ -f "$SRC" && ! -f "$DST" ]]; then
    if git rev-parse --is-inside-work-tree >/dev/null 2>&1 \
       && git ls-files --error-unmatch "$SRC" >/dev/null 2>&1; then
        git mv "$SRC" "$DST"
    else
        mv "$SRC" "$DST"
    fi
    echo "    renamed: $SRC -> $DST"
elif [[ -f "$DST" ]]; then
    echo "    already in place: $DST"
else
    echo "    skipped (source not found): $SRC"
fi

echo
echo "==> Fix 4/4: \\usepackage{ltechnical-design-spec} and stale references in .tex/.sty files"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    mapfile -t FILES < <(git ls-files '*.tex' '*.sty')
else
    mapfile -t FILES < <(find . \( -name '*.tex' -o -name '*.sty' \) -not -path './.git/*' -type f)
fi
PATCHED=0
SCANNED=0
for f in "${FILES[@]}"; do
    SCANNED=$((SCANNED + 1))
    # Skip the .sty file we just fixed in step 1 (its \ProvidesPackage was patched
    # surgically; do not touch it again).
    if [[ "$f" == *"technical-design-spec.sty" ]]; then
        continue
    fi
    if grep -q 'ltechnical-design-spec' "$f"; then
        sed -i.bak 's/ltechnical-design-spec/technical-design-spec/g' "$f"
        rm -f "${f}.bak"
        PATCHED=$((PATCHED + 1))
    fi
done
echo "    scanned $SCANNED .tex/.sty files, patched $PATCHED."

echo
echo "==> Verifying no residual occurrences..."
# `grep -r` returns 1 when nothing matches; that is success here.
REMAINING=$(grep -rl 'ltechnical-design-spec' --include='*.tex' --include='*.sty' . 2>/dev/null || true)
if [[ -n "$REMAINING" ]]; then
    echo "!! Files still match. Investigate:"
    echo "$REMAINING"
    exit 1
fi
echo "==> Clean. All package-name mismatches resolved."
