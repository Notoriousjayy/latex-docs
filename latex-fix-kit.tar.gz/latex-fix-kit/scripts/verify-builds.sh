#!/usr/bin/env bash
# verify-builds.sh — Smoke-test LaTeX compilation after the fix kit is applied.
# Walks src/ for build roots (\documentclass at the top), compiles each with
# latexmk, and reports a tally.
#
# Usage: ./scripts/verify-builds.sh [SUBDIR]
#   SUBDIR optional — restrict to e.g. 'security' to verify one subtree at a time.

set -uo pipefail

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$REPO_ROOT"
SUBDIR="${1:-}"
SCAN_ROOT="src${SUBDIR:+/$SUBDIR}"

if [[ ! -d "$SCAN_ROOT" ]]; then
    echo "error: $SCAN_ROOT not found" >&2
    exit 2
fi

# Make tooling/ visible to pdflatex.
export TEXINPUTS="${REPO_ROOT}/tooling/latex//:${REPO_ROOT}/tooling/styles/latex//:${TEXINPUTS:-}"

LOG_DIR="build-logs"
mkdir -p "$LOG_DIR"

ok=0
fail=0
fail_list=()

mapfile -t ROOTS < <(grep -rl --include='*.tex' '^\s*\\documentclass' "$SCAN_ROOT" | sort)
echo "==> Found ${#ROOTS[@]} build root(s) under $SCAN_ROOT"
echo "==> TEXINPUTS=$TEXINPUTS"
echo

for tex in "${ROOTS[@]}"; do
    rel="${tex#./}"
    dir="$(dirname "$tex")"
    base="$(basename "$tex" .tex)"
    log="$LOG_DIR/${rel%.tex}.verify.log"
    mkdir -p "$(dirname "$log")"

    if ( cd "$dir" && \
         latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error \
                 "$base.tex" >"$REPO_ROOT/$log" 2>&1 ); then
        ok=$((ok + 1))
        printf '  \033[32m\u2713\033[0m %s\n' "$rel"
    else
        fail=$((fail + 1))
        fail_list+=("$rel")
        printf '  \033[31m\u2717\033[0m %s  (see %s)\n' "$rel" "$log"
    fi
done

echo
echo "============================================================"
echo "VERIFY: $ok passed, $fail failed (of ${#ROOTS[@]} total)"
echo "============================================================"
if (( fail > 0 )); then
    echo "Failing roots:"
    printf '  %s\n' "${fail_list[@]}"
    exit 1
fi
exit 0
