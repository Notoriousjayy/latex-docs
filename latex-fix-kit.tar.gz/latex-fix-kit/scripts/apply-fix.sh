#!/usr/bin/env bash
# apply-fix.sh — One-shot orchestrator. Runs every stage of the fix kit with
# safety gates: refuses to proceed on a dirty tree without --yes, verifies a
# slice before doing the rename pass, and pauses for human confirmation
# before destructive steps.
#
# Stages:
#   1. Apply package-name typo fixes (typo in technical-design-spec.sty, base.sty,
#      latex-docs-style.sty rename, \usepackage references).
#   2. Relocate plantuml from tooling/styles/plantuml/ to tooling/plantuml/.
#   3. Drop the .latexmkrc and .github/workflows/build-latex-docs.yml into place.
#   4. Spot-verify a slice (architecture/style-system/examples/) compiles.
#   5. Plan the file-naming-convention rename; pause for review.
#   6. Apply renames and rewrite cross-references.
#   7. Full-tree verification.
#
# Usage:
#   ./apply-fix.sh                    interactive
#   ./apply-fix.sh --yes              skip all prompts (CI use)
#   ./apply-fix.sh --skip-rename      don't run stages 5 & 6
#   ./apply-fix.sh --skip-relocate    don't run stage 2 (keep plantuml where it is)
#   ./apply-fix.sh --skip-ci          don't drop .latexmkrc / workflow

set -euo pipefail

YES=0
SKIP_RENAME=0
SKIP_RELOCATE=0
SKIP_CI=0
REPO="$(pwd)"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --yes)            YES=1 ;;
        --skip-rename)    SKIP_RENAME=1 ;;
        --skip-relocate)  SKIP_RELOCATE=1 ;;
        --skip-ci)        SKIP_CI=1 ;;
        --repo)           REPO="$2"; shift ;;
        -h|--help)
            sed -n '2,/^$/p' "$0" | sed 's/^# //;s/^#//'
            exit 0 ;;
        *) echo "unknown arg: $1" >&2; exit 2 ;;
    esac
    shift
done

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO"

confirm() {
    if [[ "$YES" == "1" ]]; then return 0; fi
    read -r -p "$1 [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]]
}
banner() { printf '\n\033[1;36m=== %s ===\033[0m\n' "$1"; }

banner "Preflight"
[[ -d "$REPO/tooling" && -d "$REPO/src" ]] || {
    echo "error: $REPO does not look like the latex-docs repo (missing tooling/ or src/)" >&2
    exit 2
}
command -v pdflatex >/dev/null || { echo "error: pdflatex not found" >&2; exit 2; }
command -v python3  >/dev/null || { echo "error: python3 not found" >&2; exit 2; }
command -v latexmk  >/dev/null || { echo "error: latexmk not found" >&2; exit 2; }

if git -C "$REPO" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    if ! git -C "$REPO" diff --quiet || ! git -C "$REPO" diff --cached --quiet; then
        echo "warning: working tree is dirty"
        confirm "Proceed anyway?" || exit 1
    fi
    echo "  on branch: $(git -C "$REPO" rev-parse --abbrev-ref HEAD)"
fi
echo "  repo: $REPO"
echo "  kit:  $KIT_ROOT"

banner "Stage 1/7 — Patch package-name / filename typos"
bash "$KIT_ROOT/scripts/fix-tooling-typos.sh" "$REPO"

if [[ "$SKIP_RELOCATE" == "1" ]]; then
    banner "Stage 2/7 — SKIPPED (--skip-relocate)"
else
    banner "Stage 2/7 — Relocate PlantUML to tooling/plantuml/"
    YES=$YES bash "$KIT_ROOT/scripts/relocate-plantuml.sh" "$REPO"
fi

if [[ "$SKIP_CI" == "1" ]]; then
    banner "Stage 3/7 — SKIPPED (--skip-ci)"
else
    banner "Stage 3/7 — Install .latexmkrc and workflow"
    if [[ ! -f "$REPO/.latexmkrc" ]] || confirm "Overwrite existing .latexmkrc?"; then
        cp -v "$KIT_ROOT/ci/.latexmkrc" "$REPO/.latexmkrc"
    fi
    mkdir -p "$REPO/.github/workflows"
    if [[ ! -f "$REPO/.github/workflows/build-latex-docs.yml" ]] \
       || confirm "Overwrite existing build-latex-docs.yml?"; then
        cp -v "$KIT_ROOT/ci/build-latex-docs.yml" "$REPO/.github/workflows/build-latex-docs.yml"
    fi
fi

banner "Stage 4/7 — Spot-verify a small slice"
SLICE="architecture/style-system/examples"
if [[ -d "$REPO/src/$SLICE" ]]; then
    bash "$KIT_ROOT/scripts/verify-builds.sh" "$SLICE" || {
        echo "Spot verification failed. Investigate before continuing." >&2
        exit 1
    }
else
    echo "  (slice $SLICE not present; skipping)"
fi

if [[ "$SKIP_RENAME" == "1" ]]; then
    banner "Stages 5 & 6 SKIPPED (--skip-rename)"
else
    banner "Stage 5/7 — Generate file-rename plan"
    PLAN="$REPO/rename-plan.csv"
    python3 "$KIT_ROOT/scripts/rename-tex-files.py" \
        --root "$REPO" --dry-run --manifest "$PLAN"
    PLAN_LINES=$(($(wc -l < "$PLAN") - 1))
    echo "  Plan written to: $PLAN  ($PLAN_LINES rename(s))"
    if (( PLAN_LINES > 0 )); then
        echo "  First 10 entries:"
        head -11 "$PLAN" | tail -n +2 | nl -w3 -s'  '
        if confirm "Apply $PLAN_LINES rename(s) with cross-reference rewriting?"; then
            banner "Stage 6/7 — Apply renames"
            python3 "$KIT_ROOT/scripts/rename-tex-files.py" \
                --root "$REPO" --apply --update-refs
        else
            echo "  Renames skipped. Plan kept at $PLAN."
        fi
    else
        echo "  Plan is empty — file naming is already conformant."
    fi
fi

banner "Stage 7/7 — Full-tree verification"
if bash "$KIT_ROOT/scripts/verify-builds.sh"; then
    banner "✓ FIX KIT APPLIED SUCCESSFULLY"
else
    banner "✗ Some builds still fail — review build-logs/"
    exit 1
fi

if git -C "$REPO" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo
    echo "Suggested commit:"
    echo "  git add ."
    echo "  git commit -m 'fix(latex): patch package-name typos, relocate plantuml, normalize filenames'"
fi
